import colorama
from console import Console


class Sessao(Console):
    prompt = 'Sessão > '
    
    def __init__(self, conexao, sessoes, id):
        super().__init__()
        self.conexao = conexao
        self.sessoes = sessoes
        self.id = id
        self.endereco = self.conexao.getpeername()
    
    def interagir(self):
        """
        Permite interação com a sessão (e.g., shell).
        """
        print(f"Interagindo com a sessão: {self.endereco}")
        
        self.prompt = f"{colorama.Fore.GREEN}Sessão #{self.id} {colorama.Fore.BLUE}➜ {colorama.Fore.CYAN}{self.endereco[0]}@{self.endereco[1]}{colorama.Fore.RESET}: "
        
        self.prompt_loop()
    
    def comando_shell(self, comando):
        comando = comando.strip()
        resposta = self.mandar_comando(comando)
        print(resposta)
    
    def mandar_comando(self, comando):
        self.enviar_dados(f"shell {comando}")
        resposta = self.receber_dados().decode()
        return resposta.strip()
        
    def enviar_dados(self, buffer):
        if not isinstance(buffer, bytes):
            buffer = buffer.encode()
        try:
            self.conexao.sendall(buffer)
            return True
        except TimeoutError:
            self.printar(f"{colorama.Fore.RED}[!] Timeout durante o envio dos dados: {buffer}")
        
    def receber_dados(self):
        dados = self.conexao.recv(1024)
        if not dados:
            raise ConnectionError("Conexão encerrada durante a recepção")
        return dados
