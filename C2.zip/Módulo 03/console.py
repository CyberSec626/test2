class Console:
    prompt = 'Console > '
    
    def pegar_prompt(self):
        return self.prompt
                  
    def prompt_loop(self):
        while True:
            try:
                linha = input(self.pegar_prompt()).strip()
                if self.executar_comando(linha) and linha.startswith("sair"):
                    break
            except KeyboardInterrupt:
                print("[!] Detectado Ctrl+C. Digite 'sair' para encerrar ou continue usando o programa.")
            except EOFError:
                print("[!] Detectado Ctrl+D. Saindo...")
                return True
            except Exception as e:
                print(f"[!] Erro inesperado: {e}")
    
    def executar_comando(self, comando):
        # Separa a função dos argumentos
        # Ex: "servidor -p 4445" -> "servidor", " ", "-p 4445"
        funcao, _, argumentos = comando.partition(" ")
        try:
            # Procura pela função dentro da classe
            funcao = getattr(self, f'comando_{funcao}')
            # Verifica se tem algo escrito ou o input está em branco
            if funcao and argumentos:
                # Se achar executa a função com os argumentos
                retorno = funcao(argumentos)
            # Chama funções sem argumentos
            elif funcao and not argumentos:
                retorno = funcao("")
                
            if retorno:
                return True
        except AttributeError:
            print(f"Nenhum comando chamado '{funcao}' foi encontrado.")