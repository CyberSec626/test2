import socket
import threading
import time

HOST = '0.0.0.0'
PORTA = 5555

def tratar_mensagem(cliente, id):
    data = cliente.recv(1024).decode()  # Espera o cliente enviar algo
    print(f"Cliente disse: {data}")

    cliente.send("Servidor: recebido !".encode())  # Envia resposta
    time.sleep(2)

    print(f"Timeout da thread {id} acabou !")

    cliente.close()  # Fecha conexão antes de aceitar outro cliente

servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
servidor.bind((HOST, PORTA))
servidor.listen(5)

print("Servidor escutando...")

contador = 1
while True:
    conn, addr = servidor.accept()  # Espera até um cliente se conectar
    print(f"Conexão recebida de {addr}")
    
    threading.Thread(target=tratar_mensagem, args=(conn, contador)).start()
    contador += 1
