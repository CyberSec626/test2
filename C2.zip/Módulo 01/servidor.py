import socket
import time

HOST = '0.0.0.0'
PORTA = 5555

servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
servidor.bind((HOST, PORTA))
servidor.listen(5)

print("Servidor escutando...")

while True:
    conn, addr = servidor.accept()  # Espera até um cliente se conectar
    print(f"Conexão recebida de {addr}")

    data = conn.recv(1024).decode()  # Espera o cliente enviar algo
    print(f"Cliente disse: {data}")

    conn.send("Servidor: recebido !".encode())  # Envia resposta

    time.sleep(2)  # Simula uma tarefa

    conn.close()  # Fecha conexão antes de aceitar outro cliente
