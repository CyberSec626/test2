import socket

# Criando o socket do cliente
cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Conectando ao servidor
HOST = '127.0.0.1'
PORTA = 5555
cliente.connect((HOST, PORTA))

cliente.send("Olá, servidor!".encode())

resposta = cliente.recv(1024).decode()
print(resposta)

cliente.close()
