#!/bin/bash

for i in $(seq 1 50)
do
    python3 "cliente.py" &
done
